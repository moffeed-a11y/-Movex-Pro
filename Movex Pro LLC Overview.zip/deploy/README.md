# Movex Pro LLC — deploy

`index.html` is the whole site in one file (images, music, fonts, logo included).

## Vercel (recommended)
1. Create a free account at vercel.com.
2. Install nothing: open https://vercel.com/new → "Deploy" → drag this `deploy` folder in (or push it to a GitHub repo and import the repo).
3. Framework preset: **Other**. No build command. Output directory: `.`
4. You get a URL like `movex-pro.vercel.app`. Add a custom domain later under Settings → Domains.

## GitHub Pages
1. New public repo → upload `index.html`.
2. Settings → Pages → Branch: `main`, folder `/root` → Save.
3. Site appears at `https://<username>.github.io/<repo>/` within a minute.

## Quote form → email
The form sends through FormSubmit (free, no account).
- Set the `quoteEmail` tweak in the design to your address and re-export, **or** ask Claude to set it.
- The first submission triggers a one-time activation email from FormSubmit — click the link inside it. After that every quote request arrives in your inbox.

## Before going live
- Replace "TBD" phone, email, USDOT and MC numbers in the footer.
